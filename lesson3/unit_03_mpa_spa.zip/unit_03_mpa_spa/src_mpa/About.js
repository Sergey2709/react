function About() {
  return (
    <>
      <h1>About</h1>
    </>
  );
}

export default About;

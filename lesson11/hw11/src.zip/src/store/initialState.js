const initialState = {
    user: [
        {
            passport: 'SA070707',
            name: 'Vasyl Petrenko',
            age: '33'
        }
    ]
}

export default initialState;
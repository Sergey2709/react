function Main() {
  return (
    <div>
      <div>
        <a href="/create">Создайте note</a>
      </div>
      <div>
        <a href="/note">Просмотрите note</a>
      </div>
    </div>
  );
}

export default Main;
